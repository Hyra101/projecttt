const { generateToken, verifyToken } = require("../../authentication/token");
const Bid = require("../../db/models/bid");
const Task = require("../../db/models/task");
const User = require("../../db/models/user");

const userController = {
  registerUser: async (req, res) => {
    try {
      const user = await User.findOne({ email: req.body.email });
      if (user) {
        return res.status(404).json({ message: "User already exists" });
      }
      const newUser = new User({
        name: req.body.name,
        email: req.body.email,
        password: req.body.password,
        role: req.body.role,
        avatar: null,
      });

      console.log(newUser);

      // Save the new user record to the database
      newUser
        .save()
        .then(() => {
          console.log("User record added to database");
          res.status(200).json({
            message: "user registered successfully",
            success: true,
          });
        })
        .catch((err) => {
          console.error(err);
          res.status(400).json("Server Error");
        });
    } catch (error) {
      console.log("Error while signing in", error);
    }
  },
  loginUser: async (req, res) => {
    try {
      const user = await User.findOne({ email: req.body.email });

      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      if (user.password !== req.body.password) {
        return res.status(404).json({ message: "Password is incorrect" });
      }
      const token = generateToken({
        id: user._id,
        email: user.email,
        name: user.name,
        role: user.role,
      });
      console.log(user);
      user.token = token;

      id = user._id;
      userRole = user.role;
      await user.save();
      res.status(200).json({
        success: true,
        token,
        id,
        userRole
      });
    } catch (error) {
      console.log("Error while logging in", error);
    }
  },
  loginUserGoogle: async (req, res) => {
    try {
      console.log(req?.user?._json);
      const user = await User.findOne({
        platformId: req?.user.id,
        platform: "Google",
      });

      if (user) {
        user.name = req?.user?._json?.name;
        user.avatar = req?.user?._json?.picture || null;
        const token = generateToken({
          id: user._id,
          email: user.email,
          name: user.name,
          role: user.role,
          avatar: null,
        });
        user.token = token;
        await user.save();
        res.redirect(`http://localhost:3001/?token=${token}`);
      } else {
        const newUser = new User({
          name: req?.user?._json?.name,
          role: null,
          avatar: null,
          // token,
          platform: "Google",
          platformId: req?.user.id,
        });

        // Save the new user record to the database
        newUser
          .save()
          .then(async (user) => {
            console.log(user);
            const token = generateToken({
              id: user._id,
              email: user.email,
              name: user.name,
              role: user.role,
            });
            user.token = token;
            await user.save();
            res.redirect(`http://localhost:3001/?token=${token}`);
          })
          .catch((err) => {
            console.error(err);
            res.redirect("http://localhost:3001?error=true");
          });
      }
    } catch (error) {
      console.log("Error while logging in", error);
    }
  },
  updateUser: async (req, res) => {
    try {
      const token = req.headers["x-access-token"];
      const decodedToken = verifyToken(token);
      const userId = decodedToken.id;
      if (!userId) {
        res.status(400).json({
          success: false,
          message: "user not found",
        });
      }
      const user = await User.findOne({
        _id: userId,
      });
      if (!user) {
        res.status(400).json({
          success: false,
          message: "user not found",
        });
      }

      const { role, name, email, data } = req.body;

      if (role) {
        user.role = role;
      }

      if (name) {
        user.name = name;
      }

      if (email) {
        user.email = email;
      }
      if (data) {
        user.data = { ...data };
      }

      let updatedToken = null;

      if (role || name || email) {
        updatedToken = generateToken({
          id: user._id,
          email: user.email,
          name: user.name,
          role: user.role,
        });
        user.token = updatedToken;
      }

      await user.save();

      res.status(200).json({
        success: true,
        updatedToken,
        user,
      });
    } catch (error) {
      console.log("Error while updating user", error);
    }
  },
  updateUserAvatar: async (req, res) => {
    try {
      const token = req.headers["x-access-token"];
      const decodedToken = verifyToken(token);
      const userId = decodedToken.id;
      if (!userId) {
        res.status(400).json({
          success: false,
          message: "user not found",
        });
      }
      const user = await User.findOne({
        _id: userId,
      });
      if (!user) {
        res.status(400).json({
          success: false,
          message: "user not found",
        });
      }

      if (req.file.buffer) {
        user.avatar = {
          base64Image: req.file.buffer.toString("base64"),
          contentType: req.file.mimetype || "",
        };
      }
      console.log(user.avatar);
      await user.save();

      res.status(200).json({
        success: true,
        user,
      });
    } catch (error) {
      console.log("Error while updating user avatar", error);
    }
  },
  updateUserResume: async (req, res) => {
    try {
      const token = req.headers["x-access-token"];
      const decodedToken = verifyToken(token);
      const userId = decodedToken.id;
      if (!userId) {
        res.status(400).json({
          success: false,
          message: "user not found",
        });
      }
      const user = await User.findOne({
        _id: userId,
      });
      if (!user) {
        res.status(400).json({
          success: false,
          message: "user not found",
        });
      }

      user.resume = {
        filename: req.file.originalname,
        data: req.file.buffer,
        contentType: req.file.mimetype,
      };
      await user.save();

      res.status(200).json({
        success: true,
        resume: user.resume,
      });
    } catch (error) {
      console.log("Error while updating user resume", error);
    }
  },
  updateUserCoverLetter: async (req, res) => {
    try {
      const token = req.headers["x-access-token"];
      const decodedToken = verifyToken(token);
      const userId = decodedToken.id;
      if (!userId) {
        res.status(400).json({
          success: false,
          message: "user not found",
        });
      }
      const user = await User.findOne({
        _id: userId,
      });
      if (!user) {
        res.status(400).json({
          success: false,
          message: "user not found",
        });
      }

      user.coverLetter = {
        filename: req.file.originalname,
        data: req.file.buffer,
        contentType: req.file.mimetype,
      };
      await user.save();

      res.status(200).json({
        success: true,
        coverLetter: user.coverLetter,
      });
    } catch (error) {
      console.log("Error while updating user cover letter", error);
    }
  },
  getUserDetails: async (req, res) => {
    try {
      const token = req.headers["x-access-token"];
      const decodedToken = verifyToken(token);
      const userId = decodedToken.id;
      if (!userId) {
        res.status(400).json({
          success: false,
          message: "user not found",
        });
      }
      const user = await User.findOne({
        _id: userId,
      });
      if (!user) {
        res.status(400).json({
          success: false,
          message: "user not found",
        });
      }

      res.status(200).json({
        success: true,
        user,
      });
    } catch (error) {
      console.log("Error while getting user details", error);
    }
  },
  getUserDetailsById: async (req, res) => {
    try {
      const userId = req.params.userId;
  
      if (!userId) {
        return res.status(400).json({
          success: false,
          message: "User ID is required",
        });
      }
  
      const user = await User.findOne({
        _id: userId,
      });
  
      if (!user) {
        return res.status(404).json({
          success: false,
          message: "User not found",
        });
      }
  
      res.status(200).json({
        success: true,
        user,
      });
    } catch (error) {
      console.log("Error while getting user details by ID", error);
      res.status(500).json({
        success: false,
        message: "Internal server error",
      });
    }
  },
  getFreelancers: async (req, res) => {
    try {
      let freelancers = await User.find({
        role: "freelancer",
      });

      // calculate rating for freelancers and add in response
      for (const [index, freelancer] of freelancers.entries()) {
        let rating = 0;
        let totalRatingCount = 0;
        const bids = await Bid.find({ userId: freelancer._id });
        if (bids?.length > 0) {
          const bidIds = bids.map((bid) => {
            return bid._id.toString();
          });
          const tasks = await Task.find({
            acceptedBid: { $in: bidIds },
          });
          if (tasks?.length > 0) {
            tasks.forEach((task) => {
              if (task?.review?.rating) {
                rating = rating + parseInt(task?.review?.rating);
                totalRatingCount = totalRatingCount + 1;
              }
            });
          }
        }
        freelancers[index]._doc.rating = rating
          ? Math.floor(rating / totalRatingCount)
          : null;
      }

      res.status(200).json({
        success: true,
        freelancers,
      });
    } catch (error) {
      console.log("Error while getting freelancers", error);
    }
  },
  getEmployers: async (req, res) => {
    try {
      const employers = await User.find({
        role: "employer",
      });

      // calculate rating for freelancers and add in response
      for (const [index, employer] of employers.entries()) {
        let rating = 0;
        let totalRatingCount = 0;
        const tasks = await Task.find({ userId: employer._id });
        if (tasks?.length > 0) {
          const taskIds = tasks.map((task) => {
            return task._id.toString();
          });
          const bids = await Bid.find({
            taskId: { $in: taskIds },
          });
          if (bids?.length > 0) {
            bids.forEach((bid) => {
              if (bid?.review?.rating) {
                rating = rating + parseInt(bid?.review?.rating);
                totalRatingCount = totalRatingCount + 1;
              }
            });
          }
        }
        employers[index]._doc.rating = rating
          ? Math.floor(rating / totalRatingCount)
          : null;
      }

      res.status(200).json({
        success: true,
        employers,
      });
    } catch (error) {
      console.log("Error while getting employers", error);
    }
  },
  removeUserResume: async (req, res) => {
    try {
      const token = req.headers["x-access-token"];
      const decodedToken = verifyToken(token);
      const userId = decodedToken.id;
      if (!userId) {
        res.status(400).json({
          success: false,
          message: "user not found",
        });
      }
      const user = await User.findOne({
        _id: userId,
      });
      if (!user) {
        res.status(400).json({
          success: false,
          message: "user not found",
        });
      }

      user.resume = null;
      await user.save();

      res.status(200).json({
        success: true,
      });
    } catch (error) {
      console.log("Error while removing user resume", error);
    }
  },
  removeUserCoverLetter: async (req, res) => {
    try {
      const token = req.headers["x-access-token"];
      const decodedToken = verifyToken(token);
      const userId = decodedToken.id;
      if (!userId) {
        res.status(400).json({
          success: false,
          message: "user not found",
        });
      }
      const user = await User.findOne({
        _id: userId,
      });
      if (!user) {
        res.status(400).json({
          success: false,
          message: "user not found",
        });
      }

      user.coverLetter = null;
      await user.save();

      res.status(200).json({
        success: true,
      });
    } catch (error) {
      console.log("Error while removing user cover letter", error);
    }
  },
  updateNotificationsStatus: async (req, res) => {
    try {
      const token = req.headers["x-access-token"];
      const decodedToken = verifyToken(token);
      const userId = decodedToken.id;
      if (!userId) {
        res.status(400).json({
          success: false,
          message: "user not found",
        });
      }
      const user = await User.findOne({
        _id: userId,
      });
      if (!user) {
        res.status(400).json({
          success: false,
          message: "user not found",
        });
      }

      let dataCopy = user.data || {};
      let notificationsCopy = dataCopy.notifications
        ? [...dataCopy.notifications]
        : [];
      notificationsCopy.forEach((notification, index) => {
        notificationsCopy[index].isRead = true;
      });
      dataCopy.notifications = [...notificationsCopy];
      await User.findOneAndUpdate({ _id: user._id }, { data: dataCopy });

      res.status(200).json({
        success: true,
      });
    } catch (error) {
      console.log("Error while updating user notifications status", error);
    }
  },

  generateTokenByEmail: async (req, res) => {
    try {
      const { email } = req.body;
  
      // Find user by email
      const user = await User.findOne({ email });
      if (!user) {
        return res.status(400).json({
          success: false,
          message: "User not found",
        });
      }
  
      // Generate a token
      const token = generateToken({
        id: user._id,
        email: user.email,
        name: user.name,
        role: user.role,
      });

      user.token = token;
      id = user._id;
      userRole = user.role;
     
      
      res.status(200).json({
        success: true,
        token,
        id,
        userRole

      });
    } catch (error) {
      console.log("Error while generating token by email", error);
      res.status(500).json({
        success: false,
        message: "An error occurred while generating the token",
      });
    }
  },

  changePassword: async (req, res) => {
    try {
      const token = req.headers["x-access-token"];
      const decodedToken = verifyToken(token);
      const userId = decodedToken.id;
  
      if (!userId) {
        return res.status(400).json({
          success: false,
          message: "User not found",
        });
      }
  
      const user = await User.findOne({ _id: userId });
      if (!user) {
        return res.status(400).json({
          success: false,
          message: "User not found",
        });
      }
  
      const { newPassword } = req.body;
  
      // Update the password directly without checking current password
      user.password = newPassword;
  
      // Save the updated user data
      await user.save();
  
      res.status(200).json({
        success: true,
        message: "Password updated successfully",
      });
    } catch (error) {
      console.log("Error while changing password", error);
      res.status(500).json({
        success: false,
        message: "An error occurred while changing the password",
      });
    }
  },
  
  
  
  


};

module.exports = userController;
